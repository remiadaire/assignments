//a variable to add up from
var count = 12;

//selecting line 47 in html to manipulate
var countElement=document.querySelector(".count")

//function gets called when button gets clicked on line 48 in html
function add1() {
    //taking count variable and adding +1 everytime function is called
    count++;

    //selecting line 47 in html and extracting the inner text
    countElement.innerHTML = `${count} like(s)`
}

//a variable to add up from
var count1 = 9;

//selecting line 47 in html to manipulate
var count1Element=document.querySelector(".count1")

//function gets called when button gets clicked on line 48 in html
function add2() {
    //taking count variable and adding +1 everytime function is called
    count1++;

    //selecting line 47 in html and extracting the inner text
    count1Element.innerHTML = `${count1} like(s)`
}

//a variable to add up from
var count3 = 9;

//selecting line 47 in html to manipulate
var count3Element=document.querySelector(".count3")

//function gets called when button gets clicked on line 48 in html
function add3() {
    //taking count variable and adding +1 everytime function is called
    count3++;

    //selecting line 47 in html and extracting the inner text
    count3Element.innerHTML = `${count3} like(s)`
}





